import sys
from pathlib import Path

# Add project root directory to sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

import streamlit as st
import requests
from config import BACKEND_URL, LOGO_PATH
from ai_core.generator import sanitize_text, format_docx, format_pdf, format_html_preview

# 1. Page Configuration
st.set_page_config(
    page_title="LegalEase - AI Legal Document Generator",
    page_icon="⚖️",
    layout="centered"
)

# Custom Styling for polished appearance
st.markdown(
    """
    <style>
    .main {
        padding-top: 1rem;
    }
    .stButton>button {
        border-radius: 8px;
        font-weight: 600;
    }
    .preview-box {
        background-color: #0f172a;
        color: #f8fafc;
        padding: 24px;
        border-radius: 10px;
        border: 1px solid #334155;
        max-height: 480px;
        overflow-y: auto;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2);
    }
    </style>
    """,
    unsafe_allow_html=True
)

# 2. Header and Logo Display (Three-Column Layout)
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    if Path(LOGO_PATH).exists():
        st.image(str(LOGO_PATH), use_container_width=True)

st.markdown(
    "<h2 style='text-align: center; margin-top: -10px; margin-bottom: 25px;'>AI Legal Document Generator</h2>",
    unsafe_allow_html=True
)

# Sidebar with Example Scenarios
st.sidebar.title("⚖️ LegalEase Presets")
st.sidebar.markdown("Select a sample scenario from the project brief to auto-fill the form:")

scenario = st.sidebar.selectbox(
    "Choose a Scenario:",
    [
        "Custom Input",
        "Scenario 1: Employment Contract",
        "Scenario 2: Non-Disclosure Agreement (NDA)",
        "Scenario 3: Residential Lease Agreement",
        "Scenario 4: Freelance Work Contract"
    ]
)

default_type = ""
default_parties = ""
default_terms = ""
default_date = "April 15, 2025"

if scenario == "Scenario 1: Employment Contract":
    default_type = "Employment Contract"
    default_parties = "Apex Dynamics Inc. (Employer), Alex Morgan (Employee)"
    default_terms = (
        "Position: Senior Full-Stack Engineer; "
        "Base Salary: $120,000 per annum payable monthly; "
        "Standard 40 hours per week; "
        "Confidentiality and proprietary rights clause; "
        "30 days notice required for termination without cause"
    )
elif scenario == "Scenario 2: Non-Disclosure Agreement (NDA)":
    default_type = "Non-Disclosure Agreement (NDA)"
    default_parties = "InnovateX Labs (Disclosing Party), John Doe (Receiving Party)"
    default_terms = (
        "Confidential information includes proprietary algorithms and source code; "
        "Non-disclosure obligations remain in effect for 3 years; "
        "Standard exclusions for publicly known information; "
        "Governing law of the State of Delaware"
    )
elif scenario == "Scenario 3: Residential Lease Agreement":
    default_type = "Residential Lease Agreement"
    default_parties = "XYZ Realty Corp (Landlord), Alice Smith (Tenant)"
    default_terms = (
        "Premises: Apartment 4B, 100 Sunset Blvd; "
        "Monthly Rent: $2,200 due on the 1st of each month; "
        "Security Deposit: $2,200 refundable upon move-out inspection; "
        "No pets without written permission; "
        "Lease term of 12 months"
    )
elif scenario == "Scenario 4: Freelance Work Contract":
    default_type = "Freelance Work Contract"
    default_parties = "Jane Doe (Service Provider), TechNova Inc. (Client)"
    default_terms = (
        "Work must be delivered by May 15, 2025; "
        "Payment will be made within 7 days of invoice; "
        "The client retains intellectual property rights; "
        "Confidentiality must be maintained at all times; "
        "Either party may terminate with 15 days notice"
    )

# 3. User Input Form
with st.form("contract_input_form"):
    document_type = st.text_input(
        "Document Type (Ex. Agreement, Contract, NDA)",
        value=default_type,
        placeholder="e.g. Freelance Work Contract"
    )
    parties = st.text_area(
        "Parties Involved",
        value=default_parties,
        placeholder="e.g. Jane Doe (Service Provider), TechNova Inc. (Client)",
        height=70
    )
    terms = st.text_area(
        "Terms & Conditions (Use semicolons for bullet points)",
        value=default_terms,
        placeholder="e.g. Payment within 30 days; Intellectual property retained by client; Confidentiality maintained...",
        height=110
    )
    dates = st.text_input(
        "Effective Date",
        value=default_date,
        placeholder="e.g. April 15, 2025"
    )

    generate_btn = st.form_submit_button("⚡ Generate Document", type="primary", use_container_width=True)

# 4. Handle Document Generation Request
if generate_btn:
    if not document_type.strip() or not parties.strip():
        st.error("Please provide at least the Document Type and Parties Involved.")
    else:
        with st.spinner("Drafting professional legal document with Gemini AI..."):
            payload = {
                "document_type": document_type,
                "parties": parties,
                "terms": terms,
                "dates": dates
            }
            try:
                res = requests.post(f"{BACKEND_URL}/generate", json=payload, timeout=90)
                if res.status_code == 200:
                    data = res.json()
                    doc_content = data.get("document", "")
                    clean_doc = sanitize_text(doc_content)
                    st.session_state["generated_text"] = clean_doc
                    st.session_state["document_type"] = document_type
                    st.session_state["terms"] = terms
                    st.session_state["dates"] = dates
                    st.session_state["show_edit"] = False
                    st.success("✔ Document Generated Successfully!")
                else:
                    st.error(f"Backend API Error ({res.status_code}): {res.text}")
            except requests.exceptions.ConnectionError:
                st.error(
                    f"❌ Could not connect to FastAPI backend at {BACKEND_URL}.\n\n"
                    "Please ensure the backend server is running: `uvicorn legalEaseAPI.main:app --reload`"
                )
            except Exception as e:
                st.error(f"An unexpected error occurred: {str(e)}")

# 5. Render Document Display, Inline Edit & Multi-Format Downloads
if "generated_text" in st.session_state and st.session_state["generated_text"]:
    current_doc = st.session_state["generated_text"]
    doc_title = st.session_state.get("document_type", "Legal_Document")
    file_slug = doc_title.lower().replace(" ", "_").replace("/", "_")

    st.markdown("---")
    st.subheader(f"📄 Preview: {doc_title}")

    # Toggle Edit Button
    edit_col1, edit_col2 = st.columns([1, 1])
    with edit_col1:
        if st.button("✏️ Click to Edit Document", use_container_width=True):
            st.session_state["show_edit"] = not st.session_state.get("show_edit", False)

    # Inline Editor if activated
    if st.session_state.get("show_edit", False):
        st.markdown("#### Edit Document Below:")
        edited_content = st.text_area(
            label="Live Contract Editor",
            value=current_doc,
            height=320,
            label_visibility="collapsed"
        )
        if edited_content != current_doc:
            st.session_state["generated_text"] = sanitize_text(edited_content)
            current_doc = st.session_state["generated_text"]

    # Styled HTML Preview Box
    rendered_html = format_html_preview(current_doc)
    st.markdown(
        f'<div class="preview-box">{rendered_html}</div>',
        unsafe_allow_html=True
    )

    st.markdown("<br>", unsafe_allow_html=True)
    st.subheader("📥 Export & Download Document")

    down_col1, down_col2, down_col3 = st.columns(3)

    # 1. Download as TXT
    with down_col1:
        st.download_button(
            label="💾 Download as .TXT",
            data=current_doc,
            file_name=f"{file_slug}.txt",
            mime="text/plain",
            use_container_width=True
        )

    # 2. Download as DOCX
    with down_col2:
        try:
            docx_bytes = format_docx(
                text=current_doc,
                doc_type=doc_title,
                terms_raw=st.session_state.get("terms", "")
            )
            st.download_button(
                label="📘 Download as .DOCX",
                data=docx_bytes,
                file_name=f"{file_slug}.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                use_container_width=True
            )
        except Exception as e:
            st.warning(f"DOCX export error: {e}")

    # 3. Download as PDF
    with down_col3:
        try:
            pdf_bytes = format_pdf(
                text=current_doc,
                doc_type=doc_title
            )
            st.download_button(
                label="📕 Download as .PDF",
                data=pdf_bytes,
                file_name=f"{file_slug}.pdf",
                mime="application/pdf",
                use_container_width=True
            )
        except Exception as e:
            st.warning(f"PDF export error: {e}")
